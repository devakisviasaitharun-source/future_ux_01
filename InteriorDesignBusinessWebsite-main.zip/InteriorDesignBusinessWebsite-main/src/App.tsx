import { FormEvent, ReactNode, useEffect, useState } from "react";

type Route = "home" | "services" | "service" | "projects" | "about" | "contact" | "success" | "case-study";

const photos = {
  hero: "https://images.unsplash.com/photo-1663811396744-f86d18cdf073?auto=format&fit=crop&w=1800&q=85",
  living: "https://images.unsplash.com/photo-1663811397007-010e535ffcd7?auto=format&fit=crop&w=1200&q=85",
  kitchen: "https://images.unsplash.com/photo-1663811396760-b6c84fa45ee9?auto=format&fit=crop&w=1200&q=85",
  bedroom: "https://images.unsplash.com/photo-1663811397207-418a92396ad5?auto=format&fit=crop&w=1200&q=85",
  home: "https://images.unsplash.com/photo-1663811397219-c572550dffc5?auto=format&fit=crop&w=1200&q=85",
  project1: "https://images.unsplash.com/photo-1663811396649-b042463b8900?auto=format&fit=crop&w=1200&q=85",
  project2: "https://images.unsplash.com/photo-1663811397091-9a13493eff11?auto=format&fit=crop&w=1200&q=85",
  project3: "https://images.unsplash.com/photo-1663811396672-83dd3f32f312?auto=format&fit=crop&w=1200&q=85",
};

const services = [
  ["Living Room Design", "Comfortable, welcoming spaces created around everyday living.", photos.living],
  ["Kitchen Design", "Beautiful, practical kitchens where every detail has a purpose.", photos.kitchen],
  ["Bedroom Design", "Calm, personal retreats designed for rest and renewal.", photos.bedroom],
  ["Full Home Interiors", "One thoughtful vision carried seamlessly through your entire home.", photos.home],
  ["Renovation Consultation", "Clear expert direction before your renovation decisions begin.", photos.project2],
  ["Space Planning", "Layouts that make every room flow and every corner work harder.", photos.project1],
];

const projects = [
  ["Modern Apartment", "Full Home", photos.project1],
  ["Warm Minimal Home", "Full Home", photos.hero],
  ["Contemporary Villa", "Living Rooms", photos.project3],
  ["Elegant Bedroom", "Bedrooms", photos.bedroom],
  ["Compact Urban Kitchen", "Kitchens", photos.kitchen],
  ["Family Living Space", "Living Rooms", photos.living],
];

const navItems: [string, Route][] = [
  ["Home", "home"],
  ["Services", "services"],
  ["Projects", "projects"],
  ["About", "about"],
  ["Contact", "contact"],
];

function Icon({ name }: { name: "arrow" | "menu" | "close" | "check" | "mail" | "phone" | "pin" }) {
  const paths: Record<string, ReactNode> = {
    arrow: <><path d="M5 12h14M13 6l6 6-6 6" /></>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16" /></>,
    close: <><path d="M6 6l12 12M18 6L6 18" /></>,
    check: <path d="M5 12l4 4L19 7" />,
    mail: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3 7l9 6 9-6" /></>,
    phone: <path d="M7 3H4a1 1 0 00-1 1c0 9.4 7.6 17 17 17a1 1 0 001-1v-3l-5-2-2 2c-3-1.3-5.7-4-7-7l2-2-2-5z" />,
    pin: <><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1116 0z" /><circle cx="12" cy="10" r="2.5" /></>,
  };
  return <svg className="icon" viewBox="0 0 24 24" aria-hidden="true">{paths[name]}</svg>;
}

function Heading({ level = 2, children, className = "" }: { level?: 1 | 2 | 3; children: ReactNode; className?: string }) {
  const Tag = `h${level}` as "h1" | "h2" | "h3";
  return <Tag className={`heading h${level} ${className}`}>{children}</Tag>;
}

function LinkButton({ children, to, secondary = false, full = false }: { children: ReactNode; to: Route; secondary?: boolean; full?: boolean }) {
  return <a className={`btn ${secondary ? "btn-secondary" : "btn-primary"} ${full ? "btn-full" : ""}`} href={`#/${to}`}>{children}<Icon name="arrow" /></a>;
}

function TextLink({ children, to = "service" as Route }: { children: ReactNode; to?: Route }) {
  return <a className="text-link" href={`#/${to}`}>{children}<Icon name="arrow" /></a>;
}

function Eyebrow({ children }: { children: ReactNode }) {
  return <p className="eyebrow">{children}</p>;
}

function Logo() {
  return <a className="logo" href="#/home"><strong>UrbanNest</strong><span>INTERIORS</span></a>;
}

function Header({ route }: { route: Route }) {
  const [open, setOpen] = useState(false);
  return <header className="site-header">
    <div className="nav-wrap">
      <Logo />
      <nav className="desktop-nav" aria-label="Primary navigation">
        {navItems.map(([label, to]) => <a key={to} className={route === to ? "active" : ""} href={`#/${to}`}>{label}</a>)}
      </nav>
      <div className="nav-actions">
        <a className="btn btn-primary header-cta" href="#/contact">Book Consultation</a>
        <button className="menu-button" onClick={() => setOpen(!open)} aria-label="Toggle menu" aria-expanded={open}><Icon name={open ? "close" : "menu"} /></button>
      </div>
    </div>
    {open && <nav className="mobile-nav" aria-label="Mobile navigation">
      {navItems.map(([label, to]) => <a key={to} href={`#/${to}`} onClick={() => setOpen(false)}>{label}<Icon name="arrow" /></a>)}
      <LinkButton to="contact" full>Book Free Consultation</LinkButton>
    </nav>}
  </header>;
}

function Footer() {
  return <footer className="footer">
    <div className="container footer-grid">
      <div><Logo /><p>Thoughtful interiors designed around<br />the way you live.</p><span className="demo-pill">Fictional portfolio concept</span></div>
      <div><h3>Explore</h3>{navItems.map(([label, to]) => <a key={to} href={`#/${to}`}>{label}</a>)}</div>
      <div><h3>Contact</h3><a href="mailto:hello@urbannestinteriors.example">hello@urbannestinteriors.example</a><p>+91 90000 00000</p><p>Narasaraopet, Andhra Pradesh</p></div>
      <div><h3>Start a project</h3><p>Have a space in mind? Let’s talk about what it could become.</p><TextLink to="contact">Book a consultation</TextLink></div>
    </div>
    <div className="container footer-bottom"><span>© 2026 UrbanNest Interiors. Demo concept for Future Interns UI/UX Task.</span><a href="#/case-study">View UX Case Study</a></div>
  </footer>;
}

function Layout({ route, children }: { route: Route; children: ReactNode }) {
  return <><Header route={route} /><main>{children}</main>{route !== "success" && <Footer />}<a className="mobile-sticky" href="#/contact">Book Free Consultation <Icon name="arrow" /></a></>;
}

function SectionHead({ eyebrow, title, copy, center = false }: { eyebrow?: string; title: string; copy?: string; center?: boolean }) {
  return <div className={`section-head ${center ? "center" : ""}`}>{eyebrow && <Eyebrow>{eyebrow}</Eyebrow>}<Heading>{title}</Heading>{copy && <p>{copy}</p>}</div>;
}

function PageHero({ eyebrow, title, copy, image }: { eyebrow?: string; title: string; copy: string; image?: string }) {
  return <section className={`page-hero ${image ? "page-hero-split" : ""}`}>
    <div className="container page-hero-inner">
      <div>{eyebrow && <Eyebrow>{eyebrow}</Eyebrow>}<Heading level={1}>{title}</Heading><p className="lead">{copy}</p>{title.includes("Living Rooms") && <LinkButton to="contact">Book Free Consultation</LinkButton>}</div>
      {image && <div className="page-hero-image"><img src={image} alt="Warm modern living room interior" /></div>}
    </div>
  </section>;
}

function ImageCard({ item, type = "service" }: { item: string[]; type?: "service" | "project" }) {
  const [title, copy, image] = item;
  return <article className={`image-card ${type}`}>
    <a className="card-image" href={type === "service" ? "#/service" : "#/contact"}><img src={image} alt={`${title} interior design concept`} /></a>
    <div className="card-body">{type === "project" && <span className="card-label">{copy} · Demo concept</span>}<Heading level={3}>{title}</Heading>{type === "service" && <p>{copy}</p>}<TextLink to={type === "service" ? "service" : "contact"}>{type === "service" ? "View details" : "View project"}</TextLink></div>
  </article>;
}

function Steps({ detail = false }: { detail?: boolean }) {
  const data = detail
    ? [["01", "Understand Your Space"], ["02", "Define Your Style"], ["03", "Develop the Design"], ["04", "Bring the Concept Together"]]
    : [["01", "Discover"], ["02", "Plan"], ["03", "Design"], ["04", "Transform"]];
  return <div className="steps">{data.map(([num, title]) => <article key={num} className="step"><span>{num}</span><div><Heading level={3}>{title}</Heading><p>{detail ? "A collaborative step shaped around your needs and preferences." : ["We listen to your needs, routines, and ideas.", "We map the space, priorities, and direction.", "We shape every material, detail, and mood.", "Your considered concept comes to life."][Number(num) - 1]}</p></div></article>)}</div>;
}

function Cta({ title = "Ready to Transform Your Space?", copy = "Start with a free consultation and tell us what you have in mind." }: { title?: string; copy?: string }) {
  return <section className="cta-section"><div className="container cta-card"><div><Eyebrow>YOUR HOME, THOUGHTFULLY DESIGNED</Eyebrow><Heading>{title}</Heading><p>{copy}</p></div><LinkButton to="contact">Book Free Consultation</LinkButton></div></section>;
}

function Home() {
  return <Layout route="home">
    <section className="home-hero"><div className="container hero-grid">
      <div className="hero-copy"><Eyebrow>INTERIOR DESIGN FOR MODERN LIVING</Eyebrow><Heading level={1}>Transform Your Home Into a Space You Love</Heading><p className="lead">Thoughtful interior design that brings together your lifestyle, personality, and the way you want to live.</p><div className="button-row"><LinkButton to="contact">Book Free Consultation</LinkButton><LinkButton to="projects" secondary>View Our Projects</LinkButton></div><p className="micro">Local residential design studio · Narasaraopet</p></div>
      <div className="hero-visual"><img src={photos.hero} alt="Warm contemporary living room in neutral tones" /><div className="image-note"><span>Design note / 01</span><strong>Warm minimalism<br />for everyday living</strong></div></div>
    </div></section>
    <section className="trust"><div className="container"><div className="trust-intro"><Eyebrow>PORTFOLIO DEMO CONTENT</Eyebrow><Heading>Designed Around the Way You Live</Heading><p>Illustrative metrics created solely to demonstrate the intended website experience.</p></div><div className="metrics">{[["500+", "Project Concepts"], ["8+", "Years of Design Inspiration"], ["4.9/5", "Demo Client Rating"]].map(([n, l]) => <div key={l}><strong>{n}</strong><span>{l}</span></div>)}</div></div></section>
    <section className="section"><div className="container"><SectionHead eyebrow="WHAT WE DESIGN" title="Our Interior Design Services" copy="From one room to your whole home, discover thoughtful design support made for real life." /><div className="grid grid-4">{services.slice(0, 4).map((s) => <ImageCard key={s[0]} item={s} />)}</div><div className="section-link"><TextLink to="services">Explore all services</TextLink></div></div></section>
    <section className="section warm"><div className="container"><SectionHead eyebrow="SELECTED CONCEPTS" title="Spaces We Love to Create" copy="A curated look at the styles, moods, and rooms that inspire our design direction." /><div className="grid grid-3">{projects.slice(0, 3).map((p) => <ImageCard key={p[0]} item={p} type="project" />)}</div></div></section>
    <section className="section"><div className="container"><SectionHead eyebrow="OUR PROCESS" title="How We Create Your Perfect Space" /><Steps /></div></section>
    <Cta />
  </Layout>;
}

function Services() {
  return <Layout route="services"><PageHero eyebrow="DESIGN SUPPORT FOR EVERY SPACE" title="Interior Design Services" copy="Thoughtful spaces designed around your lifestyle, needs, and personality." />
    <section className="section first-section"><div className="container grid grid-3">{services.map((s) => <ImageCard key={s[0]} item={s} />)}</div></section>
    <section className="section warm"><div className="container guidance"><div><Eyebrow>PERSONAL GUIDANCE</Eyebrow><Heading>Not Sure Where to Start?</Heading><p>Tell us about your space and we’ll help you find the right design direction.</p></div><LinkButton to="contact">Get Design Guidance</LinkButton></div></section>
    <Cta />
  </Layout>;
}

function ServiceDetail() {
  const features = [["Space Planning", "Balanced layouts that support movement and conversation."], ["Furniture Selection", "Pieces chosen for comfort, scale, and lasting appeal."], ["Lighting Design", "Layered lighting for every mood and moment."], ["Color & Material Selection", "A cohesive, tactile palette with warmth and depth."], ["Decor Styling", "Considered finishing details that feel personal."], ["Storage Solutions", "Practical storage that blends quietly into the room."]];
  return <Layout route="services"><PageHero eyebrow="LIVING ROOM DESIGN" title="Living Rooms Designed Around You" copy="Create a living room that feels comfortable, functional, and uniquely yours." image={photos.living} />
    <section className="section"><div className="container"><SectionHead eyebrow="A COMPLETE APPROACH" title="Everything Your Living Room Needs" /><div className="feature-grid">{features.map(([title, copy], i) => <article key={title} className="feature-card"><span>0{i + 1}</span><Heading level={3}>{title}</Heading><p>{copy}</p></article>)}</div></div></section>
    <section className="section navy"><div className="container"><SectionHead eyebrow="FROM IDEAS TO DIRECTION" title="A Clear, Collaborative Process" /><Steps detail /></div></section>
    <section className="section warm"><div className="container"><SectionHead eyebrow="DEMO PORTFOLIO" title="Living Room Transformations" /><div className="grid grid-3">{projects.filter((p) => p[1] === "Living Rooms" || p[0] === "Warm Minimal Home").map((p) => <ImageCard key={p[0]} item={p} type="project" />)}</div></div></section>
    <section className="section"><div className="container feedback"><div><Eyebrow>SAMPLE PORTFOLIO FEEDBACK</Eyebrow><Heading>What Our Clients Say</Heading><p>This illustrative feedback demonstrates how trust content could appear. It is not a verified customer testimonial.</p></div><blockquote>“The process felt clear and considered from the first conversation. The concept balanced the calm look we wanted with how our family actually uses the room.”<cite>Sample feedback · Fictional portfolio content</cite></blockquote></div></section>
    <Cta title="Ready to Design Your Perfect Living Room?" />
  </Layout>;
}

function Projects() {
  const [filter, setFilter] = useState("All");
  const filtered = filter === "All" ? projects : projects.filter((p) => p[1] === filter);
  return <Layout route="projects"><PageHero eyebrow="CURATED DESIGN CONCEPTS" title="Spaces Designed With Purpose" copy="Explore our interior design concepts across different styles and spaces." />
    <section className="section first-section"><div className="container"><div className="filters" role="group" aria-label="Project categories">{["All", "Living Rooms", "Kitchens", "Bedrooms", "Full Home"].map((x) => <button key={x} className={filter === x ? "selected" : ""} onClick={() => setFilter(x)}>{x}</button>)}</div><div className="grid grid-3 projects-grid">{filtered.map((p) => <ImageCard key={p[0]} item={p} type="project" />)}</div></div></section>
    <Cta title="Have a Space in Mind?" copy="Tell us what you’re planning and let’s shape the first ideas together." />
  </Layout>;
}

function About() {
  const philosophy = [["Function First", "Beautiful spaces begin by understanding how they need to work."], ["Personal Expression", "Your home should reflect your story, not follow a formula."], ["Timeless Simplicity", "We prefer considered choices that feel good beyond passing trends."]];
  return <Layout route="about"><PageHero eyebrow="OUR POINT OF VIEW" title="Design That Feels Like Home" copy="At UrbanNest Interiors, we believe great interiors should be beautiful, practical, and personal." image={photos.project2} />
    <section className="section"><div className="container"><SectionHead eyebrow="OUR DESIGN PHILOSOPHY" title="Beautiful. Practical. Personal." /><div className="feature-grid three">{philosophy.map(([t, c], i) => <article className="feature-card" key={t}><span>0{i + 1}</span><Heading level={3}>{t}</Heading><p>{c}</p></article>)}</div></div></section>
    <section className="section warm"><div className="container"><SectionHead eyebrow="HOW WE WORK" title="A Process With Clarity Built In" /><Steps /></div></section>
    <section className="section"><div className="container"><SectionHead eyebrow="THE URBANNEST APPROACH" title="What Makes Our Approach Different" center /><div className="icon-cards">{[["Personalized Guidance", "Advice shaped around your home, pace, and priorities."], ["Clear Communication", "Straightforward steps and decisions without the overwhelm."], ["Thoughtful Design", "Every choice works together with a reason behind it."]].map(([t, c]) => <article key={t}><span><Icon name="check" /></span><Heading level={3}>{t}</Heading><p>{c}</p></article>)}</div></div></section>
    <Cta title="Let’s Create Your Space" />
  </Layout>;
}

function Field({ label, type = "text", required = true, options, placeholder }: { label: string; type?: string; required?: boolean; options?: string[]; placeholder?: string }) {
  return <label className={`field ${type === "textarea" ? "field-wide" : ""}`}><span>{label}{required && " *"}</span>{options ? <select required={required} defaultValue=""><option value="" disabled>Select an option</option>{options.map((o) => <option key={o}>{o}</option>)}</select> : type === "textarea" ? <textarea rows={5} placeholder={placeholder} /> : <input type={type} required={required} placeholder={placeholder || `Enter your ${label.toLowerCase()}`} />}</label>;
}

function Contact() {
  const submit = (e: FormEvent) => { e.preventDefault(); window.location.hash = "/success"; };
  return <Layout route="contact"><section className="contact-hero"><div className="container"><Eyebrow>LET’S CREATE SOMETHING BEAUTIFUL</Eyebrow><Heading level={1}>Let’s Design Your Dream Home</Heading><p className="lead">Tell us about your space, your ideas, and what you want to create.</p></div></section>
    <section className="contact-main"><div className="container contact-grid"><aside><Eyebrow>START A CONVERSATION</Eyebrow><Heading level={2}>Your home starts with a simple hello.</Heading><p>Share a few details and this demo experience will show you the next step in the consultation journey.</p><div className="contact-list"><div><Icon name="mail" /><span><small>Email</small>hello@urbannestinteriors.example</span></div><div><Icon name="phone" /><span><small>Phone</small>+91 90000 00000</span></div><div><Icon name="pin" /><span><small>Studio area</small>Narasaraopet, Andhra Pradesh</span></div></div><p className="demo-notice">Demo business details for a UI/UX portfolio concept. No real consultation request is sent.</p></aside>
      <form className="form-card" onSubmit={submit}><div><Eyebrow>FREE CONSULTATION REQUEST</Eyebrow><Heading level={2}>Tell Us About Your Project</Heading><p>Fields marked with * are required.</p></div><div className="form-grid"><Field label="Full Name" /><Field label="Phone Number" type="tel" /><Field label="Email Address" type="email" /><Field label="Service Needed" options={["Living Room Design", "Kitchen Design", "Bedroom Design", "Full Home Interiors", "Renovation Consultation", "Other"]} /><Field label="Project Type" options={["New Home", "Renovation", "Apartment", "Villa", "Individual Room"]} /><Field label="Project Details" type="textarea" required={false} placeholder="Tell us about your space, style, budget, or requirements..." /></div><button className="btn btn-primary submit-button" type="submit">Request Free Consultation <Icon name="arrow" /></button><p className="privacy"><Icon name="check" />Your information is only used to contact you about your project.</p></form>
    </div></section>
    <section className="section"><div className="container"><SectionHead eyebrow="A THOUGHTFUL FIRST STEP" title="Why Start With UrbanNest?" center /><div className="icon-cards">{[["Personalized Ideas", "A direction shaped around your needs."], ["Clear Communication", "Simple, transparent next steps."], ["Designed Around You", "No one-size-fits-all solutions."]].map(([t, c]) => <article key={t}><span><Icon name="check" /></span><Heading level={3}>{t}</Heading><p>{c}</p></article>)}</div></div></section>
    <section className="section warm"><div className="container"><SectionHead eyebrow="WHAT HAPPENS NEXT" title="From First Note to Design Direction" /><div className="journey">{["Share Your Requirements", "Free Consultation", "Design Direction", "Bring It To Life"].map((x, i) => <div key={x}><span>0{i + 1}</span><strong>{x}</strong>{i < 3 && <Icon name="arrow" />}</div>)}</div></div></section>
  </Layout>;
}

function Success() {
  return <Layout route="success"><section className="success"><div className="success-card"><div className="success-icon"><Icon name="check" /></div><Eyebrow>CONSULTATION REQUEST RECEIVED</Eyebrow><Heading level={1}>Thank You!</Heading><p className="lead">Your consultation request has been received.</p><p>In this demo journey, the UrbanNest team would review your requirements and contact you using the details you provided.</p><div className="button-row"><LinkButton to="home">Back to Home</LinkButton><LinkButton to="services" secondary>Explore Services</LinkButton></div><span className="demo-pill">Portfolio prototype · No data was submitted</span></div></section></Layout>;
}

function CaseStudy() {
  return <Layout route="case-study"><section className="case-hero"><div className="container"><Eyebrow>FUTURE INTERNS · UI/UX DESIGN TASK 1</Eyebrow><Heading level={1}>UrbanNest Interiors<br />Local Service Business Website Redesign</Heading><p className="lead">A conversion-focused digital experience for a fictional local residential interior design studio.</p><div className="case-meta"><div><span>Project</span><strong>Portfolio case study</strong></div><div><span>Focus</span><strong>UX strategy + Responsive UI</strong></div><div><span>Role</span><strong>Research to prototype</strong></div></div></div></section>
    <section className="section"><div className="container case-grid"><SectionHead eyebrow="01 · RESEARCH & USER FLOW" title="Understanding the First Step" copy="Customers often struggle to understand interior services, compare design options, and know how to take the first step." /><div className="case-panel"><span>BUSINESS GOAL</span><Heading level={3}>Convert website visitors into consultation leads.</Heading></div><div className="user-grid">{[["New Homeowners", "Complete interior planning and design guidance."], ["Renovating Families", "Modern redesign ideas and practical planning."], ["Working Professionals", "Quick consultation and efficient design support."], ["Apartment Owners", "Space-efficient interior solutions."]].map(([t, c]) => <article key={t}><Heading level={3}>{t}</Heading><p>{c}</p></article>)}</div><div className="flow">{["Discover UrbanNest", "Explore Services", "View Examples", "Build Trust", "Book Consultation", "Submit Requirements", "Confirmation"].map((x, i) => <div key={x}><span>{i + 1}</span><strong>{x}</strong></div>)}</div></div></section>
    <section className="section warm"><div className="container"><SectionHead eyebrow="02 · WIREFRAMES" title="Structure Before Style" copy="Three priority journeys were mapped in low fidelity to clarify hierarchy and conversion paths." /><div className="wireframes">{[["Homepage", ["Header", "Hero + CTA", "Services", "Projects", "Process", "CTA", "Footer"]], ["Service Detail", ["Header", "Service Hero", "Features", "Process", "Projects", "Feedback", "CTA"]], ["Contact", ["Header", "Contact Hero", "Lead Form", "Trust", "Process", "Footer"]]].map(([title, blocks]) => <article key={title as string}><Heading level={3}>{title as string}</Heading><div>{(blocks as string[]).map((b, i) => <span className={i === 1 ? "tall" : ""} key={b}>{b}</span>)}</div></article>)}</div></div></section>
    <section className="section"><div className="container"><SectionHead eyebrow="03 · DESIGN SYSTEM" title="Warm, Editorial, Consistent" copy="A focused visual language balances premium cues with approachable service-business clarity." /><div className="design-board"><div className="swatches">{[["Navy", "#1F3A5F"], ["Gold", "#C89B5B"], ["Warm", "#F7F5F1"], ["Ink", "#1C1C1C"], ["Gray", "#666666"], ["White", "#FFFFFF"]].map(([n, h]) => <div key={n} style={{ background: h, color: n === "Navy" || n === "Ink" ? "white" : "#1C1C1C" }}><strong>{n}</strong><span>{h}</span></div>)}</div><div className="type-sample"><span>PLAYFAIR DISPLAY · HEADINGS</span><Heading>Design that feels like home.</Heading><span>INTER · BODY AND UI</span><p>Thoughtful spaces shaped around your life, needs, and personal style.</p><div className="button-row"><LinkButton to="contact">Primary Button</LinkButton><LinkButton to="services" secondary>Secondary Button</LinkButton></div></div></div></div></section>
    <section className="section navy"><div className="container"><SectionHead eyebrow="04–06 · RESPONSIVE UI & PROTOTYPE" title="One Connected Experience" copy="Seven responsive views share a consistent header, footer, cards, CTAs, interaction language, and mobile conversion path." /><div className="decision-grid">{["Clear primary CTA", "Service-based architecture", "Strong visual hierarchy", "Short lead-generation form", "Responsive mobile experience", "Trust-building demo labels", "Consistent design system"].map((x, i) => <article key={x}><span>0{i + 1}</span><strong>{x}</strong></article>)}</div></div></section>
    <section className="section"><div className="container"><SectionHead eyebrow="07 · OUTCOME" title="A Clearer Path From Interest to Inquiry" /><div className="before-after"><div><span>BEFORE</span>{["Unclear service discovery", "Weak CTA", "Long information search", "Difficult contact process"].map((x) => <p key={x}>{x}</p>)}</div><div><span>AFTER</span>{["Clear services", "Visible consultation CTA", "Structured content", "Simple contact form", "Easy mobile access"].map((x) => <p key={x}><Icon name="check" />{x}</p>)}</div></div><div className="final-outcome"><Eyebrow>FINAL OUTCOME</Eyebrow><Heading>UrbanNest Interiors now provides a clearer, more modern and conversion-focused digital experience.</Heading><LinkButton to="home">Explore the Website</LinkButton></div></div></section>
  </Layout>;
}

function getRoute(): Route {
  const value = window.location.hash.replace("#/", "") as Route;
  return ["home", "services", "service", "projects", "about", "contact", "success", "case-study"].includes(value) ? value : "home";
}

export default function App() {
  const [route, setRoute] = useState<Route>(getRoute());
  useEffect(() => {
    const change = () => { setRoute(getRoute()); window.scrollTo({ top: 0, behavior: "smooth" }); };
    window.addEventListener("hashchange", change);
    return () => window.removeEventListener("hashchange", change);
  }, []);
  const pages: Record<Route, ReactNode> = { home: <Home />, services: <Services />, service: <ServiceDetail />, projects: <Projects />, about: <About />, contact: <Contact />, success: <Success />, "case-study": <CaseStudy /> };
  return pages[route];
}
